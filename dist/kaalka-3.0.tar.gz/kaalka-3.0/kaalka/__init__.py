# Expose Kaalka class for direct import
from .file_encryptor import Kaalka
