"""
Kaalka package initializer

Exposes the Kaalka class for direct import.
"""
from .file_encryptor import Kaalka
